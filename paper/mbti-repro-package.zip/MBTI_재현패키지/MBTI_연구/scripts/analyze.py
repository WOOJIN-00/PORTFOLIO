# -*- coding: utf-8 -*-
"""
MBTI 판정 일관성 분석 스크립트
입력: ../data/raw_data.csv  (rater,text_id,source,type,EI,SN,TF,JP)
출력: 콘솔 요약 + ../data/summary.csv
표준 라이브러리만 사용 (설치 불필요).
실행: python analyze.py
"""
import csv, os
from collections import Counter, defaultdict

BASE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(BASE, "..", "data", "raw_data.csv")
OUT = os.path.join(BASE, "..", "data", "summary.csv")

rows = []
with open(RAW, encoding="utf-8") as f:
    for r in csv.DictReader(f):
        rows.append(r)

texts = ["T1", "T2", "T3", "T4"]
axes = ["EI", "SN", "TF", "JP"]

by_text = defaultdict(list)
for r in rows:
    by_text[r["text_id"]].append(r)

print("=== 글별 반복/세션 간 일관성 (실험1) ===")
summary = []
for t in texts:
    recs = by_text[t]
    n = len(recs)
    type_counts = Counter(x["type"] for x in recs)
    modal_type, modal_n = type_counts.most_common(1)[0]
    modal_ratio = modal_n / n
    n_distinct = len(type_counts)
    # 축별 최빈 비율(일치율)
    axis_agree = {}
    for a in axes:
        c = Counter(x[a] for x in recs)
        axis_agree[a] = c.most_common(1)[0][1] / n
    src = recs[0]["source"]
    print(f"[{t}/{src}] n={n} 최빈유형={modal_type}({modal_ratio:.0%}) "
          f"서로다른유형수={n_distinct} 축일치율 "
          + " ".join(f"{a}={axis_agree[a]:.0%}" for a in axes))
    summary.append({
        "text_id": t, "source": src, "n": n,
        "modal_type": modal_type, "modal_ratio": f"{modal_ratio:.2f}",
        "n_distinct_types": n_distinct,
        **{f"agree_{a}": f"{axis_agree[a]:.2f}" for a in axes},
    })

print("\n=== 주제 민감성 (실험2): 같은 저자(본인) T1 vs T2 ===")
t1 = Counter(x["type"] for x in by_text["T1"]).most_common(1)[0][0]
t2 = Counter(x["type"] for x in by_text["T2"]).most_common(1)[0][0]
flips = [a for a, (c1, c2) in zip(axes, zip(t1, t2)) if c1 != c2]
print(f"T1(취미) 최빈={t1}  T2(계획) 최빈={t2}")
print(f"뒤집힌 축: {flips if flips else '없음'}  (총 {len(flips)}/4개 축 변화)")

print("\n=== 4개 글 전체 최빈유형 ===")
for t in texts:
    c = Counter(x["type"] for x in by_text[t]).most_common(1)[0][0]
    print(f"  {t}: {c}")

with open(OUT, "w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(summary[0].keys()))
    w.writeheader()
    w.writerows(summary)
print(f"\n요약 저장: {os.path.normpath(OUT)}")
