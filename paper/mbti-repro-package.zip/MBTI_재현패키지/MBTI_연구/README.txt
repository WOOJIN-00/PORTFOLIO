재현 방법 (Reproduction)
========================

연구 제목: 글만 보고 성격을 맞힐 수 있을까 — AI의 MBTI 판정 일관성과 주제 민감성 분석
작성일: 2026-10-16

[폴더 구성]
  stimuli/            판정 대상 글 4개(T1~T4)와 출처
  scripts/rater_prompt.txt   실험에 사용한 평가 프롬프트 전문
  scripts/analyze.py         원자료 -> 요약 재생성 스크립트 (표준 라이브러리만 사용)
  data/raw_data.csv          원자료 60행 (15 세션 x 4 글)
  data/summary.csv           집계 결과
  paper/논문.md               본문(서론·방법·결과·논의·참고문헌)
  paper/00_주제선정_가설기록.md  주제 선정과 가설 기록
  paper/figure1.svg          그림 1
  paper/AI와_나의_판단_3줄.txt  AI/본인 판단 구분
  README.txt                 이 파일

[데이터를 어떻게 모았나]
  1) scripts/rater_prompt.txt 의 프롬프트에 stimuli/ 의 글 4개를 넣는다.
  2) 서로 격리된 독립 AI 세션 15개에 각각 1회 투입한다.
     (사용 모델: Claude Sonnet / 독립 서브에이전트 세션)
  3) 각 세션이 글 4개에 대해 MBTI 4글자 + 4지표를 출력한다.
  4) 모든 결과를 data/raw_data.csv 에 기록한다.

[짧은 확인 — 집계 재생성]
  Windows PowerShell 또는 터미널에서:
     cd scripts
     py analyze.py        (또는: python analyze.py)
  -> data/summary.csv 가 원자료로부터 그대로 재생성된다.
  (한글이 깨져 보이면 터미널 코드페이지 문제일 뿐, 저장 파일은 정상.)

[사람이 직접 재현하려면 (AI 없이 손으로)]
  새 대화창(ChatGPT/Claude 등)을 열 때마다 rater_prompt.txt 를 그대로 붙여넣고
  나온 4글자 유형을 기록한다. 이전 답을 지우고 매번 새 창에서 15회 반복한다.

[주의 / 한계]
  본 실험의 독립 세션은 거의 결정론적으로 같은 출력을 내므로, 회차별 변동(0%)은
  일반 챗봇의 실시간 변동을 과소추정했을 수 있다. 자세한 내용은 논문 4.4 한계 참조.
